from simfin.tools import account

class gov_enterprises(account):
    '''
    Classe permettant d'intégrer les revenus provenant des entreprises du gouvernement provincial.
    '''
    pass
