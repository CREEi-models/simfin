from simfin.tools import account

class property_taxes(account):
    '''
    Classe permettant d'intégrer l'impôt foncier.
    '''
    pass
