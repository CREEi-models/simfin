import numpy as np
from simfin.tools import accounts

class collector(accounts):
    '''
    Fonction qui permet de colliger différentes dépenses publiques provinciales.
    '''
    pass
