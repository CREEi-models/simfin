from simfin.tools import account

class permits(account):
    '''
    Classe permettant d'intégrer les revenus issus des droits et permis.
    '''
    pass
