from simfin.tools import account

class fss(account):
    '''
    Classe permettant d'intégrer les cotisations au Fonds des services de santé (FSS).
    '''
    pass
