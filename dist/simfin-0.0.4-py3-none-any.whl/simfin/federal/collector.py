import numpy as np
from simfin.tools import accounts 

class collector(accounts):
    '''
    Fonction qui permet de colliger les transferts issus du gouvernement fédéral.
    '''
    pass