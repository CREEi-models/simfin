# Modèle de microsimulation SimFin

Ce package contient le modèle de microsimulation des finances publiques SimFin développé par la chaire [CREEi](http://www.creei.ca). La [documentation](https://creei-models.github.io/simfin) du modèle devrait être consulté concernant l'installation et l'utilisation du modèle.
